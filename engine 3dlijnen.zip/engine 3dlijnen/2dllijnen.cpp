//
// Created by Seher Goker on 20/03/2024.
//

#include "2dllijnen.h"
img::EasyImage draw2DLines(Lines2D &lines, const int size, const img::Color &color){
    double max_x = lines.front().p1.x;
    double min_x = lines.front().p1.x;
    double max_y = lines.front().p1.y;
    double min_y =lines.front().p1.y;




    //max en min y en x berekenen
    for(auto line : lines) {

        if (line.p1.x > max_x){
            max_x = line.p1.x;
        }
        if (line.p2.x > max_x){
            max_x = line.p2.x;
        }
        if (line.p1.x < min_x){
            min_x = line.p1.x;
        }
        if (line.p2.x < min_x){
            min_x = line.p2.x;
        }
        if (line.p1.y > max_y){
            max_y = line.p1.y;
        }
        if (line.p2.y > max_y){
            max_y = line.p2.y;
        }
        if (line.p1.y < min_y){
            min_y = line.p1.y;
        }
        if (line.p2.y < min_y){
            min_y = line.p2.y;
        }
    }


    //breedte en hoogte van tekening
    double range_x = max_x - min_x;
    double range_y = max_y - min_y;

    //image hoogte en breedte
    //wrm imagex en y? omdat je het moet schalen omdat afbeelding niet altijd vierkant zal zijn.
    //sommige tekeningen zijn langer of breeder.
    double imagex = size *(range_x / std::max(range_x,range_y));
    double imagey = size *(range_y / std::max(range_x,range_y));
    img::EasyImage image((unsigned int)lround(imagex),(unsigned int)lround(imagey), color);

    //schaalfactor
    double d = 0.95* (imagex/ range_x);

    for(auto& line : lines) {
        line.p1.x *= d;
        line.p1.y *= d;
        line.p2.x *= d;
        line.p2.y *= d;
    }


    double DcX = d * (min_x + max_x)/2;
    double DcY = d * (min_y + max_y)/2;

    double dx = (imagex /2 ) - DcX;
    double dy = (imagey /2 ) - DcY;


    for(auto& line : lines) {
        line.p1.x +=  dx;
        line.p1.y +=  dy;
        line.p2.x +=  dx;
        line.p2.y +=  dy;
    }

    for (auto &line : lines){
        image.draw_line(
                line.p1.x,
                line.p1.y,
                line.p2.x,
                line.p2.y,
                {
                        static_cast<uint8_t>(lround(line.color.red * 255)),
                        static_cast<uint8_t>(lround(line.color.green * 255)),
                        static_cast<uint8_t>(lround(line.color.blue * 255))
                }
        );


    }
    return image;
};



Lines2D createLines(const std::string &generated_string, const LParser::LSystem2D &l_system, const Color &color){

    double angle = (l_system.get_angle() / 180) * M_PI;
    double startingAngle = (l_system.get_starting_angle() / 180) * M_PI;
    std::set<char> alphabet = l_system.get_alphabet();
    Lines2D lines = {};
    Point2D p1(0, 0);
    Point2D p2(0, 0);
    std::vector<std::vector<double>> stack;




    for (char c : generated_string){
        const bool is_in = alphabet.find(c) != alphabet.end();
        if (is_in){
            if (l_system.draw(c)) {
                p1 = p2;
                p2 = {p1.x + cos(startingAngle), p1.y + sin(startingAngle)};
                Line2D line(p1, p2, color);
                lines.push_back(line);
            }
            else {
                p1 = p2;
                p2 = {p1.x + cos(startingAngle), p1.y + sin(startingAngle)};
            }
        }


        else if (c == '+'){
            startingAngle += angle;

        }
        else if (c == '-'){
            startingAngle -= angle;

        }
        else if (c == '('){
            stack.push_back({p2.x, p2.y, startingAngle});



        }

        else if (c == ')'){
            p2.x = stack.back()[0];
            p2.y = stack.back()[1];
            startingAngle = stack.back()[2];
            stack.pop_back();
        }



    }

    return lines;


}