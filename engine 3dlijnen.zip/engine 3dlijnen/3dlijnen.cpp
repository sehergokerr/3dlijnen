//
// Created by Seher Goker on 20/03/2024.
//

#include "3dlijnen.h"


Matrix scaleFigure(const double scale){

    Matrix m = Matrix();
    m(1,1) = scale;
    m(2,2) = scale;
    m(3,3) = scale;
    m(4,4) = 1;


    return m;
}


Matrix rotateX(const double angle){
    Matrix m = Matrix();
    double rangle = angle*(M_PI/180);
    m(1,1) = 1;
    m(2,2) = std::cos(rangle);
    m(2,3) = std::sin(rangle);
    m(3,1) = -(std::sin(rangle));
    m(3,3) = std::cos(rangle);
    m(4,4) = 1;

    return m;

}

Matrix rotateY(const double angle){
    Matrix m = Matrix();
    double rangle = angle*(M_PI/180);
    m(1,1) = std::cos(rangle);
    m(1,3) = -(std::sin(rangle));
    m(2,2) =  1;
    m(3,1) = std::sin(rangle);
    m(3,3) = std::cos(rangle);
    m(4,4) = 1;

    return m;

}




Matrix rotateZ(const double angle){
    Matrix m = Matrix();
    double rangle = angle*(M_PI/180);
    m(1,1) = std::cos(rangle);
    m(1,2) = std::sin(rangle);
    m(2,1) = -(std::sin(rangle));
    m(2, 2) = std::cos(rangle);
    m(3,3) = 1;
    m(4,4) = 1;

    return m;

}

Matrix translate(const Vector3D &vector){
    Matrix m = Matrix();

    m(1,1) = 1;
    m(2,2) = 1;
    m(3,3) = 1;
    m(4,4) = 1;
    m(4,1) = vector.x;
    m(4,2) = vector.y;
    m(4,3) = vector.z;
    return m;
}




void applyTransformation(Figure &fig, const Matrix &m){
    for (auto &point: fig.points) {
        point *= m;
    }
}



void applyTransformation(Figures3D &fig, const Matrix &m){
    for (auto &figure: fig) {
        applyTransformation(figure, m);
    }
}

void toPolar(const Vector3D &point, double &theta, double &phi, double &r) {
    r = sqrt(pow(point.x,2) + pow(point.y, 2) + pow(point.z, 2));
    theta = std::atan2(point.y , point.x);
    phi = std::acos(point.z /r);


}


Matrix eyePointTrans(const Vector3D &eyepoint){

    Matrix m = Matrix();
    double theta;
    double phi;
    double r;
    toPolar(eyepoint, theta, phi, r);

    m(1,1) = -std::sin(theta);
    m(1,2) = -cos(theta) * cos(phi);
    m(1,3)= cos(theta) * sin(phi);
    m(2,1) = cos(theta);
    m(2,2) = -sin(theta) * cos(phi);
    m(2, 3) = sin(theta) * sin(phi);
    m(3,2) = sin(phi);
    m(3,3) = cos(phi);
    m(4,3) = -r;
    m(4,4)= 1;

    return m;

}

Point2D doProjection(const Vector3D &point){
    Point2D point2;

//    if(point.x == 0 && point.y ==0){
//        point2.y = point.z;
//    }

    if(point.z == 0){
        point2.x = point.x ;
        point2.y = point.y ;
    }
    else {
        point2.x = point.x / (-point.z);
        point2.y = point.y / (-point.z);
    }


    return point2;
}


Lines2D doProjection(const Figures3D &figures){
    Lines2D lines;

    for(auto figure: figures){
        for(auto face: figure.faces) {
            if(face.point_indexes.size() == 2){
                int index0 = face.point_indexes[0];
                int index1 = face.point_indexes[1];

                Line2D line;
                line.p1 = doProjection(figure.points[index0]);
                line.p2 = doProjection(figure.points[index1]);
                line.color = figure.color;
                lines.push_back(line);
            }
            else{
                for(unsigned int i = 0; i< face.point_indexes.size()-1; i++){
                    int index0 = face.point_indexes[i];
                    int index1 = face.point_indexes[i+1];

                    Line2D line;
                    line.p1 = doProjection(figure.points[index0]);
                    line.p2 = doProjection(figure.points[index1]);
                    line.color = figure.color;
                    lines.push_back(line);
                }

                int index0 = face.point_indexes[0];
                int index1 = face.point_indexes[face.point_indexes.size()-1];

                Line2D line;
                line.p1 = doProjection(figure.points[index0]);
                line.p2 = doProjection(figure.points[index1]);
                line.color = figure.color;
                lines.push_back(line);
            }



        }


    }
    return lines;
}

