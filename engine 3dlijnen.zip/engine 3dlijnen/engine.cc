#include "easy_image.h"
#include "ini_configuration.h"
#include "vector3d.h"
#include "klassen.h"
#include "3dlijnen.h"
#include "2dllijnen.h"
#include "3dlichamen.h"

#include <fstream>
#include <iostream>
#include <stdexcept>
#include <string>
#include <valarray>
#include <cmath>

























img::EasyImage generate_image(const ini::Configuration &configuration)
{
        //General
        int size = configuration["General"]["size"].as_int_or_die();
        std::vector<double> backgroundcolor = configuration["General"]["backgroundcolor"].as_double_tuple_or_die();
        //std::vector<double> color = configuration["2DLSystem"]["color"].as_double_tuple_or_die();
        int nrFigures = configuration["General"]["nrFigures"].as_int_or_die();
        std::vector<double> eye = configuration["General"]["eye"].as_double_tuple_or_die();

        Vector3D x = Vector3D::vector(eye[0], eye[1], eye[2]);

        Matrix j = eyePointTrans(x);


        //figure0
        std::string type = configuration["Figure0"]["type"].as_string_or_die();

        Figures3D figures;


        for(int i=0; i<nrFigures; i++){
            std::string mystring = "Figure" + std::to_string(i);
            std::string type = configuration[mystring]["type"].as_string_or_die();
            double rotatX = configuration[mystring]["rotateX"].as_int_or_die();
            double rotatY = configuration[mystring]["rotateY"].as_int_or_die();
            double rotatZ = configuration[mystring]["rotateZ"].as_int_or_die();
            double scale = configuration[mystring]["scale"].as_double_or_die();
            std::vector<double> center = configuration[mystring]["center"].as_double_tuple_or_die();

            Vector3D vector;
            vector.x = center[0];
            vector.y = center[1];
            vector.z = center[2];



            Matrix m = scaleFigure(scale);
            Matrix n = rotateX(rotatX);
            Matrix o = rotateY(rotatY);
            Matrix p = rotateZ(rotatZ);
            Matrix q = translate(vector);

            Matrix A;
            A = m*n*o*p*q;

            if(type == "LineDrawing"){

                int nrPoints = configuration[mystring]["nrPoints"].as_int_or_die();
                int nrLines = configuration[mystring]["nrLines"].as_int_or_die();


                //points
                Figure figure;
                for (int i = 0; i < nrPoints; i++ ){
                    std::string mystring = "point" + std::to_string(i);
                    std::vector<double> point = configuration["Figure0"][mystring].as_double_tuple_or_die();
                    Vector3D a = Vector3D::point(point[0], point[1], point[02]);
                    figure.points.emplace_back(a);
                }


                //lines
                for (int i = 0; i < nrLines; i++ ){
                    std::string mystring1 = "line" + std::to_string(i);

                    std::vector<int> line = configuration[mystring][mystring1].as_int_tuple_or_die();
                    Face newFace;
                    for (double index : line) {
                        newFace.point_indexes.push_back(index);
                    }
                    figure.faces.push_back(newFace);

                }

                std::vector<double> colorVec = configuration[mystring]["color"].as_double_tuple_or_die();
                Color lineColor(colorVec[0], colorVec[1], colorVec[2]);
                figure.color = lineColor;

                applyTransformation(figure, A);
                // Voeg de nieuwe Face toe aan de Figure

                figures.push_back(figure);
                continue;




            }
            if (type == "Cube"){
                Figure cube1;
                cube1 = cube();
                std::vector<double> colorVec = configuration[mystring]["color"].as_double_tuple_or_die();
                Color lineColor(colorVec[0], colorVec[1], colorVec[2]);
                cube1.color = lineColor;

                applyTransformation(cube1, A);
                figures.push_back(cube1);
                continue;

            }
            if (type == "Tetrahedron"){

                Figure Tetrahedron1;
                Tetrahedron1 = Tetrahedron();
                std::vector<double> colorVec = configuration[mystring]["color"].as_double_tuple_or_die();
                Color lineColor(colorVec[0], colorVec[1], colorVec[2]);
                Tetrahedron1.color = lineColor;

                applyTransformation(Tetrahedron1, A);
                figures.push_back(Tetrahedron1);
                continue;

            }
            if (type == "Octahedron"){

                Figure Octahedron1;
                Octahedron1 = Octahedron();
                std::vector<double> colorVec = configuration[mystring]["color"].as_double_tuple_or_die();
                Color lineColor(colorVec[0], colorVec[1], colorVec[2]);
                Octahedron1.color = lineColor;

                applyTransformation(Octahedron1, A);
                figures.push_back(Octahedron1);
                continue;

            }
            if (type == "Icosahedron"){

                Figure Icosahedron1;
                Icosahedron1 = Icosahedron();
                std::vector<double> colorVec = configuration[mystring]["color"].as_double_tuple_or_die();
                Color lineColor(colorVec[0], colorVec[1], colorVec[2]);
                Icosahedron1.color = lineColor;

                applyTransformation(Icosahedron1, A);
                figures.push_back(Icosahedron1);
                continue;

            }
            if (type == "Sphere"){
                const int k = configuration[mystring]["n"];
                Figure bol1;
                bol1 = bol(k);
                std::vector<double> colorVec = configuration[mystring]["color"].as_double_tuple_or_die();
                Color lineColor(colorVec[0], colorVec[1], colorVec[2]);
                bol1.color = lineColor;

                applyTransformation(bol1, A);
                figures.push_back(bol1);
                continue;

            }
            if (type == "Cone"){
                const int k = configuration[mystring]["n"];
                const double h = configuration[mystring]["height"];
                Figure bol1;
                bol1 = kegel(k, h);
                std::vector<double> colorVec = configuration[mystring]["color"].as_double_tuple_or_die();
                Color lineColor(colorVec[0], colorVec[1], colorVec[2]);
                bol1.color = lineColor;

                applyTransformation(bol1, A);
                figures.push_back(bol1);
                continue;

            }
            if (type == "Cylinder"){
                const int k = configuration[mystring]["n"];
                const double h = configuration[mystring]["height"];
                Figure cilinder1;
                cilinder1 = Cilinder(k, h);
                std::vector<double> colorVec = configuration[mystring]["color"].as_double_tuple_or_die();
                Color lineColor(colorVec[0], colorVec[1], colorVec[2]);
                cilinder1.color = lineColor;

                applyTransformation(cilinder1, A);
                figures.push_back(cilinder1);
                continue;

            }



            else{
                return img::EasyImage();
            }


        }
        applyTransformation(figures, j);
        Lines2D d = doProjection(figures);
        img::EasyImage image =  draw2DLines(d, size , {static_cast<uint8_t>(floor(255*(backgroundcolor[0]))), static_cast<uint8_t>(floor(255*(backgroundcolor[1]))), static_cast<uint8_t>(floor(255*(backgroundcolor[2])))});
        return image;

}














int main(int argc, char const* argv[])
{
        int retVal = 0;
        try
        {
                std::vector<std::string> args = std::vector<std::string>(argv+1, argv+argc);
                if (args.empty()) {
                        std::ifstream fileIn("filelist");
                        std::string filelistName;
                        while (std::getline(fileIn, filelistName)) {
                                args.push_back(filelistName);
                        }
                }
                for(std::string fileName : args)
                {
                        ini::Configuration conf;
                        try
                        {
                                std::ifstream fin(fileName);
                                if (fin.peek() == std::istream::traits_type::eof()) {
                                    std::cout << "Ini file appears empty. Does '" <<
                                    fileName << "' exist?" << std::endl;
                                    continue;
                                }
                                fin >> conf;
                                fin.close();
                        }
                        catch(ini::ParseException& ex)
                        {
                                std::cerr << "Error parsing file: " << fileName << ": " << ex.what() << std::endl;
                                retVal = 1;
                                continue;
                        }

                        img::EasyImage image = generate_image(conf);
                        if(image.get_height() > 0 && image.get_width() > 0)
                        {
                                std::string::size_type pos = fileName.rfind('.');
                                if(pos == std::string::npos)
                                {
                                        //filename does not contain a '.' --> append a '.bmp' suffix
                                        fileName += ".bmp";
                                }
                                else
                                {
                                        fileName = fileName.substr(0,pos) + ".bmp";
                                }
                                try
                                {
                                        std::ofstream f_out(fileName.c_str(),std::ios::trunc | std::ios::out | std::ios::binary);
                                        f_out << image;

                                }
                                catch(std::exception& ex)
                                {
                                        std::cerr << "Failed to write image to file: " << ex.what() << std::endl;
                                        retVal = 1;
                                }
                        }
                        else
                        {
                                std::cout << "Could not generate image for " << fileName << std::endl;
                        }
                }
        }
        catch(const std::bad_alloc &exception)
        {
    		//When you run out of memory this exception is thrown. When this happens the return value of the program MUST be '100'.
    		//Basically this return value tells our automated test scripts to run your engine on a pc with more memory.
    		//(Unless of course you are already consuming the maximum allowed amount of memory)
    		//If your engine does NOT adhere to this requirement you risk losing points because then our scripts will
		//mark the test as failed while in reality it just needed a bit more memory
                std::cerr << "Error: insufficient memory" << std::endl;
                retVal = 100;
        }
        return retVal;
}

