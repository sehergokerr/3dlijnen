//
// Created by Seher Goker on 20/03/2024.
//

#ifndef ENGINE_3DLIJNEN_2DLLIJNEN_H
#define ENGINE_3DLIJNEN_2DLLIJNEN_H

#include "klassen.h"
#include "easy_image.h"
#include "l_parser.h"

img::EasyImage draw2DLines(Lines2D &lines, const int size, const img::Color &color);
Lines2D createLines(const std::string &generated_string, const LParser::LSystem2D &l_system, const Color &color);
#endif //ENGINE_3DLIJNEN_2DLLIJNEN_H

