//
// Created by Seher Goker on 20/03/2024.
//

#ifndef ENGINE_3DLIJNEN_3DLICHAMEN_H
#define ENGINE_3DLIJNEN_3DLICHAMEN_H
#include "3dlijnen.h"
#include "2dllijnen.h"
#include "vector3d.h"
#include "klassen.h"


Figure cube();

Figure Tetrahedron();

Figure Octahedron();

Figure Icosahedron();

Figure bol(const int n);

Figure kegel(const int n, const double h);

Figure Cilinder(const int n, const double h);



#endif //ENGINE_3DLIJNEN_3DLICHAMEN_H
