//
// Created by Seher Goker on 20/03/2024.
//

#ifndef ENGINE_3DLIJNEN_3DLIJNEN_H
#define ENGINE_3DLIJNEN_3DLIJNEN_H
#include "vector3d.h"
#include "klassen.h"
#include <cmath>


Matrix scaleFigure(const double scale);
Matrix rotateX(const double angle);
Matrix rotateX(const double angle);
Matrix rotateY(const double angle);
Matrix rotateZ(const double angle);
Matrix translate(const Vector3D &vector);
void applyTransformation(Figure &fig, const Matrix &m);
void applyTransformation(Figures3D &fig, const Matrix &m);
void toPolar(const Vector3D &point, double &theta, double &phi, double &r);
Matrix eyePointTrans(const Vector3D &eyepoint);
Point2D doProjection(const Vector3D &point);
Lines2D doProjection(const Figures3D &figures);
#endif //ENGINE_3DLIJNEN_3DLIJNEN_H
