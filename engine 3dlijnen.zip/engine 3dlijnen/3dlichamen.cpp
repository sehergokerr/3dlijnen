//
// Created by Seher Goker on 20/03/2024.
//

#include "3dlichamen.h"

Figure cube(){

    Figure cube;
    Vector3D punt;

    punt.x = 1;
    punt.y = -1;
    punt.z = -1;

    cube.points.push_back(punt);


    punt.x = -1;
    punt.y = 1;
    punt.z = -1;

    cube.points.push_back(punt);

    punt.x = 1;
    punt.y = 1;
    punt.z = 1;

    cube.points.push_back(punt);


    punt.x = -1;
    punt.y = -1;
    punt.z = 1;

    cube.points.push_back(punt);


    punt.x = 1;
    punt.y = 1;
    punt.z = -1;

    cube.points.push_back(punt);


    punt.x = -1;
    punt.y = -1;
    punt.z = -1;

    cube.points.push_back(punt);

    punt.x = 1;
    punt.y = -1;
    punt.z = 1;

    cube.points.push_back(punt);

    punt.x = -1;
    punt.y = 1;
    punt.z = 1;

    cube.points.push_back(punt);



    Face face1;

    face1.point_indexes.push_back(0);
    face1.point_indexes.push_back(4);
    face1.point_indexes.push_back(2);
    face1.point_indexes.push_back(6);

    cube.faces.push_back(face1);



    Face face2;

    face2.point_indexes.push_back(4);
    face2.point_indexes.push_back(1);
    face2.point_indexes.push_back(7);
    face2.point_indexes.push_back(2);

    cube.faces.push_back(face2);


    Face face3;

    face3.point_indexes.push_back(1);
    face3.point_indexes.push_back(5);
    face3.point_indexes.push_back(3);
    face3.point_indexes.push_back(7);

    cube.faces.push_back(face3);

    Face face4;

    face4.point_indexes.push_back(5);
    face4.point_indexes.push_back(0);
    face4.point_indexes.push_back(6);
    face4.point_indexes.push_back(3);

    cube.faces.push_back(face4);




    Face face5;

    face5.point_indexes.push_back(6);
    face5.point_indexes.push_back(2);
    face5.point_indexes.push_back(7);
    face5.point_indexes.push_back(3);

    cube.faces.push_back(face5);


    Face face6;

    face6.point_indexes.push_back(0);
    face6.point_indexes.push_back(5);
    face6.point_indexes.push_back(1);
    face6.point_indexes.push_back(4);

    cube.faces.push_back(face6);

    return cube;
}

Figure Tetrahedron() {

    Figure Tetrahedron;

    Vector3D punt1;
    punt1.x = 1;
    punt1.y = -1;
    punt1.z = -1;
    Tetrahedron.points.push_back(punt1);


    Vector3D punt2;
    punt2.x = -1;
    punt2.y = 1;
    punt2.z = -1;
    Tetrahedron.points.push_back(punt2);


    Vector3D punt3;
    punt3.x = 1;
    punt3.y = 1;
    punt3.z = 1;
    Tetrahedron.points.push_back(punt3);


    Vector3D punt4;
    punt4.x = -1;
    punt4.y = -1;
    punt4.z = 1;
    Tetrahedron.points.push_back(punt4);






    //faces

    Face face1;

    face1.point_indexes.push_back(0);
    face1.point_indexes.push_back(1);
    face1.point_indexes.push_back(2);

    Tetrahedron.faces.push_back(face1);



    Face face2;

    face2.point_indexes.push_back(1);
    face2.point_indexes.push_back(3);
    face2.point_indexes.push_back(2);

    Tetrahedron.faces.push_back(face2);


    Face face3;

    face3.point_indexes.push_back(0);
    face3.point_indexes.push_back(3);
    face3.point_indexes.push_back(1);

    Tetrahedron.faces.push_back(face3);


    Face face4;

    face4.point_indexes.push_back(0);
    face4.point_indexes.push_back(2);
    face4.point_indexes.push_back(3);


    Tetrahedron.faces.push_back(face4);

    return Tetrahedron;
}

Figure Octahedron() {
    Figure Octahedron;

    Vector3D punt1;
    punt1.x = 1;
    punt1.y = 0;
    punt1.z = 0;
    Octahedron.points.push_back(punt1);

    Vector3D punt2;
    punt2.x = 0;
    punt2.y = 1;
    punt2.z = 0;
    Octahedron.points.push_back(punt2);


    Vector3D punt3;
    punt3.x = -1;
    punt3.y = 0;
    punt3.z = 0;
    Octahedron.points.push_back(punt3);


    Vector3D punt4;
    punt4.x = 0;
    punt4.y = -1;
    punt4.z = 0;
    Octahedron.points.push_back(punt4);



    Vector3D punt5;
    punt5.x = 0;
    punt5.y = 0;
    punt5.z = -1;
    Octahedron.points.push_back(punt5);



    Vector3D punt6;
    punt6.x = 0;
    punt6.y = 0;
    punt6.z = 1;
    Octahedron.points.push_back(punt6);





    Face face1;

    face1.point_indexes.push_back(0);
    face1.point_indexes.push_back(1);
    face1.point_indexes.push_back(5);

    Octahedron.faces.push_back(face1);



    Face face2;

    face2.point_indexes.push_back(1);
    face2.point_indexes.push_back(2);
    face2.point_indexes.push_back(5);

    Octahedron.faces.push_back(face2);


    Face face3;

    face3.point_indexes.push_back(2);
    face3.point_indexes.push_back(3);
    face3.point_indexes.push_back(5);

    Octahedron.faces.push_back(face3);


    Face face4;

    face4.point_indexes.push_back(3);
    face4.point_indexes.push_back(0);
    face4.point_indexes.push_back(5);


    Octahedron.faces.push_back(face4);


    Face face5;

    face5.point_indexes.push_back(1);
    face5.point_indexes.push_back(0);
    face5.point_indexes.push_back(4);


    Octahedron.faces.push_back(face5);

    Face face6;

    face6.point_indexes.push_back(2);
    face6.point_indexes.push_back(1);
    face6.point_indexes.push_back(4);


    Octahedron.faces.push_back(face6);

    Face face7;

    face7.point_indexes.push_back(3);
    face7.point_indexes.push_back(2);
    face7.point_indexes.push_back(4);


    Octahedron.faces.push_back(face7);


    Face face8;

    face8.point_indexes.push_back(0);
    face8.point_indexes.push_back(3);
    face8.point_indexes.push_back(4);


    Octahedron.faces.push_back(face8);



    return Octahedron;
}



Figure Icosahedron() {
    Figure Icosahedron;

    Vector3D punt1;
    punt1.x = 0;
    punt1.y = 0;
    punt1.z = sqrt(5)/2;
    Icosahedron.points.push_back(punt1);



    for(int i = 2; i < 7; i++) {
        Vector3D punt2;
        punt2.x = cos((i-2)*2*M_PI/5);
        punt2.y = sin((i-2)*2*M_PI / 5);
        punt2.z = 0.5;
        Icosahedron.points.push_back(punt2);
    }


    for(int i = 7; i < 12; i++) {
        Vector3D punt2;
        punt2.x = cos(M_PI/5 + (i-7)*2*M_PI /5);
        punt2.y = sin(M_PI/5 + (i-7)*2*M_PI/5);
        punt2.z = -0.5;
        Icosahedron.points.push_back(punt2);
    }


    Vector3D punt12;
    punt12.x = 0;
    punt12.y = 0;
    punt12.z = -sqrt(5)/2;
    Icosahedron.points.push_back(punt12);

    Face face1;

    face1.point_indexes.push_back(0);
    face1.point_indexes.push_back(1);
    face1.point_indexes.push_back(2);

    Icosahedron.faces.push_back(face1);



    Face face2;

    face2.point_indexes.push_back(0);
    face2.point_indexes.push_back(2);
    face2.point_indexes.push_back(3);

    Icosahedron.faces.push_back(face2);


    Face face3;

    face3.point_indexes.push_back(0);
    face3.point_indexes.push_back(3);
    face3.point_indexes.push_back(4);

    Icosahedron.faces.push_back(face3);


    Face face4;

    face4.point_indexes.push_back(0);
    face4.point_indexes.push_back(4);
    face4.point_indexes.push_back(5);


    Icosahedron.faces.push_back(face4);


    Face face5;

    face5.point_indexes.push_back(0);
    face5.point_indexes.push_back(5);
    face5.point_indexes.push_back(1);


    Icosahedron.faces.push_back(face5);

    Face face6;

    face6.point_indexes.push_back(1);
    face6.point_indexes.push_back(6);
    face6.point_indexes.push_back(2);


    Icosahedron.faces.push_back(face6);

    Face face7;

    face7.point_indexes.push_back(2);
    face7.point_indexes.push_back(6);
    face7.point_indexes.push_back(7);


    Icosahedron.faces.push_back(face7);


    Face face8;

    face8.point_indexes.push_back(2);
    face8.point_indexes.push_back(7);
    face8.point_indexes.push_back(3);


    Icosahedron.faces.push_back(face8);


    Face face9;

    face9.point_indexes.push_back(3);
    face9.point_indexes.push_back(7);
    face9.point_indexes.push_back(8);


    Icosahedron.faces.push_back(face9);

    Face face10;

    face10.point_indexes.push_back(3);
    face10.point_indexes.push_back(8);
    face10.point_indexes.push_back(4);


    Icosahedron.faces.push_back(face10);

    Face face11;

    face11.point_indexes.push_back(4);
    face11.point_indexes.push_back(8);
    face11.point_indexes.push_back(9);


    Icosahedron.faces.push_back(face11);

    Face face12;

    face12.point_indexes.push_back(4);
    face12.point_indexes.push_back(9);
    face12.point_indexes.push_back(5);


    Icosahedron.faces.push_back(face12);


    Face face13;

    face13.point_indexes.push_back(5);
    face13.point_indexes.push_back(9);
    face13.point_indexes.push_back(10);


    Icosahedron.faces.push_back(face13);



    Face face14;

    face14.point_indexes.push_back(5);
    face14.point_indexes.push_back(10);
    face14.point_indexes.push_back(1);


    Icosahedron.faces.push_back(face14);

    Face face15;

    face15.point_indexes.push_back(1);
    face15.point_indexes.push_back(10);
    face15.point_indexes.push_back(6);


    Icosahedron.faces.push_back(face15);

    Face face16;

    face16.point_indexes.push_back(11);
    face16.point_indexes.push_back(7);
    face16.point_indexes.push_back(6);


    Icosahedron.faces.push_back(face16);



    Face face17;

    face17.point_indexes.push_back(11);
    face17.point_indexes.push_back(8);
    face17.point_indexes.push_back(7);


    Icosahedron.faces.push_back(face17);



    Face face18;

    face18.point_indexes.push_back(11);
    face18.point_indexes.push_back(9);
    face18.point_indexes.push_back(8);


    Icosahedron.faces.push_back(face18);


    Face face19;

    face19.point_indexes.push_back(11);
    face19.point_indexes.push_back(10);
    face19.point_indexes.push_back(9);


    Icosahedron.faces.push_back(face19);


    Face face20;

    face20.point_indexes.push_back(11);
    face20.point_indexes.push_back(6);
    face20.point_indexes.push_back(10);


    Icosahedron.faces.push_back(face20);

    return Icosahedron;



}

Figure bol(const int n) {

    Figure bol;

    bol = Icosahedron();

    int size = bol.points.size();

    for(int i = 0; i < n ; i++){
        std::vector <Face> aantaldriehoeken;
        for(int j = 0; j< bol.faces.size(); j++){
            int index_a = bol.faces[j].point_indexes[0];
            int index_b = bol.faces[j].point_indexes[1];
            int index_c = bol.faces[j].point_indexes[2];

            Vector3D co_A = bol.points[index_a];
            Vector3D co_B = bol.points[index_b];
            Vector3D co_C = bol.points[index_c];

            Vector3D D;
            Vector3D E;
            Vector3D F;
            D.x = (co_A.x + co_B.x)/2;
            E.x = (co_A.x + co_C.x)/2;
            F.x = (co_B.x + co_C.x)/2;

            D.y = (co_A.y + co_B.y)/2;
            E.y = (co_A.y + co_C.y)/2;
            F.y = (co_B.y + co_C.y)/2;

            D.z = (co_A.z + co_B.z)/2;
            E.z = (co_A.z + co_C.z)/2;
            F.z = (co_B.z + co_C.z)/2;


            bol.points.push_back(D);
            bol.points.push_back(E);
            bol.points.push_back(F);

            Face face;
            //voeg driehoek ADE toe
            face.point_indexes.push_back(index_a);
            face.point_indexes.push_back(size); //index D
            face.point_indexes.push_back(size+1); // index E
            aantaldriehoeken.push_back(face);

            Face face2;
            //voeg driehoek BFD toe
            face2.point_indexes.push_back(index_b);
            face2.point_indexes.push_back(size); //index D
            face2.point_indexes.push_back(size+2); // index F
            aantaldriehoeken.push_back(face2);

            Face face3;
            //voeg driehoek CEF toe
            face3.point_indexes.push_back(index_c);
            face3.point_indexes.push_back(size+1); //index E
            face3.point_indexes.push_back(size+2); // index F
            aantaldriehoeken.push_back(face3);

            Face face4;
            //voeg driehoek DEF toe
            face4.point_indexes.push_back(size);
            face4.point_indexes.push_back(size+1); //index E
            face4.point_indexes.push_back(size+2); // index F
            aantaldriehoeken.push_back(face4);

            size = bol.points.size();
        }
        bol.faces = aantaldriehoeken;

    }

    //herschalen
    for(Vector3D &i: bol.points){
        double r = sqrt((i.x)*(i.x) + (i.y)* (i.y) + (i.z) *(i.z));
        i.x /= r;
        i.y /= r;
        i.z /= r;
    }
    return bol;
}

Figure kegel(const int n, const double h) {

    Figure kegel;


    for(int i =0; i<n+1; i++){
        Vector3D punt1;
        punt1.x = cos((2*i*M_PI) / n);
        punt1.y = sin((2*i*M_PI) / n);
        punt1.z = 0;

        kegel.points.push_back(punt1);

    }

    Vector3D puntn;
    puntn.x = 0;
    puntn.y = 0;
    puntn.z = h;
    kegel.points.push_back(puntn);



    for(int i = 0; i < n+1 ; i++){
        Face face;
        face.point_indexes.push_back(i);
        face.point_indexes.push_back((i+1)%n);
        face.point_indexes.push_back(n+1);
        kegel.faces.push_back(face);
    }

    Face bottomFace;
    for(int i=0; i<n+1; i++){
        bottomFace.point_indexes.push_back(i);
    }
    kegel.faces.push_back(bottomFace);


    return kegel;
}

Figure Cilinder(const int n, const double h) {
    Figure cilinder;
    //punten onderkant
    for(int i =0; i<n; i++){
        Vector3D punt1;
        punt1.x = cos((2*i*M_PI) / n);
        punt1.y = sin((2*i*M_PI) / n);
        punt1.z = 0;
        cilinder.points.push_back(punt1);
    }
    //punten bovenkant
    for(int i =0; i<n; i++){
        Vector3D punt1;
        punt1.x = cos((2*i*M_PI) / n);
        punt1.y = sin((2*i*M_PI) / n);
        punt1.z = h;
        cilinder.points.push_back(punt1);
    }

    Face bottom;
    for(int i =0; i<n; i++){
        bottom.point_indexes.push_back(i);
    }
    cilinder.faces.push_back(bottom);



    Face top;
    for(int i =n; i<2*n; i++){
        top.point_indexes.push_back(i);
    }
    cilinder.faces.push_back(top);

    for (int i = 0; i < n; i++) {
        Face face;
        int a = (i + 1) % n;            // Use modular arithmetic for cyclic indices
        int b = n + (i + 1) % n;
        int c = n + i;
        int d = i;
        face.point_indexes = {a, b, c, d};  // Directly initialize point_indexes
        cilinder.faces.push_back(face);
    }

    Face face;
    face.point_indexes = {0, n, 2 * n - 1, n - 1};  // Initialize point_indexes directly
    cilinder.faces.push_back(face);


    return cilinder;
}











