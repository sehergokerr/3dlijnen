//
// Created by Seher Goker on 21/02/2024.
//

#ifndef UNTITLED1_KLASSEN_H
#define UNTITLED1_KLASSEN_H
#include <cmath>
#include <iostream>
#include <list>
#include <vector>
#include "vector3d.h"


class Color{
public:
    double red;
    double green;
    double blue;
    Color(double r, double g, double b);

    Color();
};


class Point2D{

public:
    Point2D();

    double x;
    double y;
    Point2D(double x, double y);
};

class Line2D{
public:
    Point2D p1;
    Point2D p2;
    Color color;

    Line2D(Point2D p1, Point2D p2, Color color);
    Line2D();

};

class Face{

public:
    std::vector<int> point_indexes;
};

class Figure{
public:
    std::vector<Vector3D> points;
    std::vector<Face> faces;
    Color color;

};




using Lines2D = std::list<Line2D>;
typedef std::list<Figure> Figures3D;
#endif //UNTITLED1_KLASSEN_H
