//
// Created by Seher Goker on 06/03/2024.
//

#include "klassen.h"

Color::Color(double r, double g, double b):
        red(r), green(g), blue(b)

{
}

Color::Color() {}


Point2D::Point2D(double x, double y) :
        x(x), y(y)
{
}

Point2D::Point2D() {

}

Line2D::Line2D(Point2D p1, Point2D p2, Color color):
        p1(p1), p2(p2), color(color)
{

}

Line2D::Line2D() {

}




